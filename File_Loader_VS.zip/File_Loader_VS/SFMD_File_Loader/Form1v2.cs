﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.CodeDom;
using System.Net.Configuration;
using System.Diagnostics.Eventing.Reader;
using System.Net.Sockets;
using System.Security.Cryptography;

namespace SFMD_File_Loader
{
    public partial class upButton : Form
    {
        private string filePath                  = Environment.ExpandEnvironmentVariables("%HOMEDRIVE%%HOMEPATH%");
        private bool   isFile                    = false;
        private string currentlySelectedItemName = "";
        private string profileTxt                = "";
        private string envTxt                    = "";

        public upButton()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            filePathTextBox.Text = filePath;
            loadFilesAndDirectories();
            loadButton.Enabled = false;
            lbltext.Text = "Select a file and click on Upload button to send it to the Environments' bucket";
            pictureBox1.Visible = true;
            comboBox1.Text = "MYAPP";
            envTxt = "MYAPP";
            loadButton.Text = "Upload File (" + envTxt + ")";
            cmndText.Visible = false;
            versionLbl.Text = "v1.01";
        }

        public void loadFilesAndDirectories()
        {
            DirectoryInfo fileList;
            string tempFilePath = "";
            FileAttributes fileAttr;

            try
            {
                if (isFile)
                {
                    tempFilePath         = filePath + "/" + currentlySelectedItemName;
                    FileInfo fileDetails = new FileInfo(tempFilePath);
                    fileAttr             = File.GetAttributes(tempFilePath);
                    Process.Start(tempFilePath);
                }
                else
                {
                    fileAttr             = File.GetAttributes(filePath);
                }

                if ((fileAttr & FileAttributes.Directory) == FileAttributes.Directory)
                {
                    fileList             = new DirectoryInfo(filePath);
                    FileInfo[] files     = fileList.GetFiles();          // Get files
                    DirectoryInfo[] dirs = fileList.GetDirectories();    //Get dirs
                    string fileExtension = "";
                    listView1.Items.Clear();

                    for (int i = 0; i < files.Length; i++)
                    {
                        //listView1.Items.Add(files[i].Name, 0);
                        fileExtension = files[i].Extension.ToUpper();
                        switch (fileExtension)
                        {
                            case ".XLS":
                            case ".XLSX":
                                listView1.Items.Add(files[i].Name, 1);
                                break;
                            case ".CSV":
                                listView1.Items.Add(files[i].Name, 2);
                                break;
                            case ".JPG":
                                listView1.Items.Add(files[i].Name, 3);
                                break;
                            case ".MP4":
                                listView1.Items.Add(files[i].Name, 4);
                                break;
                            case ".PDF":
                                listView1.Items.Add(files[i].Name, 5);
                                break;
                            case ".PNG":
                                listView1.Items.Add(files[i].Name, 6);
                                break;
                            case ".DOC":
                            case ".DOCX":
                                listView1.Items.Add(files[i].Name, 7);
                                break;
                            case ".TXT":
                                listView1.Items.Add(files[i].Name, 8);
                                break;
                            default:
                                listView1.Items.Add(files[i].Name, 9);
                                break;
                        }
                    }

                    for (int i = 0; i < dirs.Length; i++)
                    {
                        listView1.Items.Add(dirs[i].Name, 0);
                    }
                }
                else
                { 
                }
            }
            catch (Exception e)
            {
            }
        }

        public void loadButtonAction()
        {
            removeBackSlash();
            filePath = filePathTextBox.Text;
            loadFilesAndDirectories();
            isFile   = false;
        }

        public void removeBackSlash()
        {
            string path = filePathTextBox.Text;
            if (path.LastIndexOf("/") == path.Length - 1)
            { 
                filePathTextBox.Text = path.Substring(0, path.Length - 1);
            }
        }

        public void goBack()
        {
            try
            {
                removeBackSlash();
                string path          = filePathTextBox.Text;
                path                 = path.Substring(0, path.LastIndexOf("/"));
                this.isFile          = false;
                filePathTextBox.Text = path;
                removeBackSlash();

            }
            catch (Exception e)
            { }


        }


        private void goButton_Click(object sender, EventArgs e)
        {
            loadButtonAction();
        }

        private void listView1_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            currentlySelectedItemName = e.Item.Text;

            FileAttributes fileAttr = File.GetAttributes(filePath + "/" + currentlySelectedItemName); 
            if ((fileAttr & FileAttributes.Directory) == FileAttributes.Directory) 
            {
                isFile = false;
                filePathTextBox.Text = filePath + "/" + currentlySelectedItemName;
                loadButton.Enabled = false;
            }
            else
            {
                isFile = true;
                loadButton.Enabled = true;
            }
        }

        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            loadButtonAction();
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            goBack();
            loadButtonAction();
        }

        private void loadButton_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to upload the file?.\n\n" + currentlySelectedItemName,"Caution", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if(result == DialogResult.Yes) 
            {
                loadButton.Enabled = false;
                bool uploadOK = true;
                string strCmdText = "";
                string fileType = "";
                string tgtBucket = "";
                string errorMsg = "";
                fileType = currentlySelectedItemName.Substring(currentlySelectedItemName.LastIndexOf(".")).ToUpper();

                string[] subs = currentlySelectedItemName.Split('_');

                switch (fileType)
                {
                    case ".XLS":
                    case ".XLSX":
                        if (System.Text.RegularExpressions.Regex.IsMatch(subs[0], "^XLS\\d{2}$"))
                        { tgtBucket = "excel/"; }
                        else
                        { errorMsg = "Incorrect File Name.\n\n" + currentlySelectedItemName + "\n\nExcel prefix name must be XLS01 thru XLS99"; }
                        break;
                    case ".CSV":
                        if (System.Text.RegularExpressions.Regex.IsMatch(subs[0], "^CSV\\d{2}$"))
                        { tgtBucket = "csv/"; }
                        else
                        { errorMsg = "Incorrect File Name.\n\n" + currentlySelectedItemName + "\n\nCSV prefix name must be CSV01 thru CSV99"; }
                        break;
                    case ".JPG":
                        if (System.Text.RegularExpressions.Regex.IsMatch(subs[0], "^JPG\\d{3}$"))
                        { tgtBucket = "jpg/"; }
                        else
                        { errorMsg = "Incorrect File Name.\n\n" + currentlySelectedItemName + "\n\nJPG prefix name must be JPG001 thru JPG999"; }
                        break;
                    case ".MP4":
                        if (System.Text.RegularExpressions.Regex.IsMatch(subs[0], "^MP4\\d{3}$"))
                        { tgtBucket = "mp4/"; }
                        else
                        { errorMsg = "Incorrect File Name.\n\n" + currentlySelectedItemName + "\n\nMP4 prefix must be MP4001 thru MP4999"; }
                        break;
                    case ".PDF":
                        if (System.Text.RegularExpressions.Regex.IsMatch(subs[0], "^PDF\\d{3}$"))
                        { tgtBucket = "pdf/"; }
                        else
                        { errorMsg = "Incorrect File Name.\n\n" + currentlySelectedItemName + "\n\nPDF prefix must be PDF001 thru PDF999"; }
                        break;
                    case ".PNG":
                        if (System.Text.RegularExpressions.Regex.IsMatch(subs[0], "^PNG\\d{3}$"))
                        { tgtBucket = "png/"; }
                        else
                        { errorMsg = "PNG File Name format is incorrect.\n\n" + currentlySelectedItemName + "\n\nPNG prefix must be PNG001 thru PNG999"; }
                        break;
                    default:
                        errorMsg = "File type not supported by the application.\n\nValid File Types are :\nXLXS, PDF, MP4, PNG, JPG, CSV";
                        break;
                }

                if (fileType == ".PDF" ^ fileType == ".PNG" ^ fileType == ".JPG" ^ fileType == ".MP4")
                {
                    if ((System.Text.RegularExpressions.Regex.IsMatch(subs[2], "^\\d{6}$") & subs[2].Length == 6) ^
                        (System.Text.RegularExpressions.Regex.IsMatch(subs[2], "^\\d{8}$") & subs[2].Length == 8))
                    { uploadOK = true; }
                    else
                    { errorMsg = "Incorrect File Name.\n\n" + currentlySelectedItemName + "\n\nThird column in name must be a date\n\nValid date format is MMDDYY or MMDDYYYY"; }
                }

                if (errorMsg != "")
                {
                    MessageBox.Show(errorMsg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    uploadOK = false;
                }

                if (uploadOK)
                {
                    strCmdText = "";
                    
                    switch (profileTxt)
                    {
                        case "VWLAB":
                            { strCmdText = "/C aws s3 cp --profile " + profileTxt + " " + filePath + "/" + currentlySelectedItemName + " s3://vws01-use1-lab-lz/" + tgtBucket; }
                            break;
                        case "VWDEV":
                            { MessageBox.Show("DEVELOPMENT environment is not available yet.", "AWS Profile", MessageBoxButtons.OK, MessageBoxIcon.Information); }
                            break;
                        case "VWPROD":
                            { MessageBox.Show("PRODUCTION environment is not available yet.", "AWS Profile", MessageBoxButtons.OK, MessageBoxIcon.Information); } 
                            break;
                    }

                    if (strCmdText != "")
                    {
                        cmndText.Text = strCmdText;
                        cmndText.Visible = true;
                        MessageBox.Show("Upload request has been processed.\n\nReview logs for additional information", "Informational", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        System.Diagnostics.Process process = new System.Diagnostics.Process();
                        System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
                        startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                        startInfo.FileName = "cmd.exe";
                        startInfo.Arguments = strCmdText;
                        process.StartInfo = startInfo;
                        process.Start();
                    }
                    
                    
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            profileTxt = "VW" + comboBox1.Text;
            envTxt     = comboBox1.Text;
            loadButton.Text = "Cargar Archivo (" + envTxt + ")";
            //MessageBox.Show("Current AWS Profile is "+ profileTxt, "AWS CLI Profile", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void versionLbl_Click(object sender, EventArgs e)
        {

        }
    }
}
